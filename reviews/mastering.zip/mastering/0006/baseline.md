# Chapter 6

The Jin Family of Taiyuan looked like an entire village from the hill above it.

Dozens of buildings, large and small, spread across the broad grounds, while high stone walls wrapped around the family estate without leaving a single gap.

And that wasn’t all. The cliff rising behind the Jin Family of Taiyuan was a spectacle in itself.

Nature that had weathered the ages, and one family crouched beneath it.

The sight alone was deeply imposing.

“Wow.”

Even the coachman was impressed. Wait, hold on.

“Didn’t you say you’d been here often?”

“This is my second time.”

“…You’ve only been working for how long?”

“Not even half a month.”

This guy had more layers than an onion.

He looked and carried himself like a twenty-year veteran, but he was a new hire.

*Then again, if he really had that much experience, there was no way he wouldn’t recognize this face.*

I’d practically worn a path to Honghwaru’s door from coming and going so often. If he was a new hire, it made sense that he might mistake me for Jin Mukyung.

*Good thing everything worked out.*

I had completed the final Tutorial Quest, and the Jin Family of Taiyuan was right in front of me. I could finally relax a little.

“Could you slow down a bit?”

“Ah, yes.”

As I felt the carriage slow, I opened my Skill Window.

> **System**
>
> Skill Window
>
> **Qi Sense**
>
> **Grade:** None
>
> **Restriction:** None
>
> **Realm:** 1st Mastery
>
> **Effect:** Can identify targets at or below Lv. 30.
>
> **Description:** Scans targets within a designated range. As the realm rises, the scan range and maximum target level increase.

When I finished reading the description, something suddenly occurred to me.

*That’s exactly what it is. A power-level scanner.*

In a famous manga, a mechanical device quantified an opponent’s battle power. I wondered what Qi Sense would be like.

Curious, I called to mind the command.

*Activate Qi Sense.*

Was that right? I hesitated for a moment, and then a blue circle appeared beneath my feet. At the same time, a notification chimed.

Ding.

> **System**
>
> - You used Qi Sense. Since your current realm is 1st Mastery, you can scan targets at or below Lv. 30 within 10 jang.

Ten jang—that was 30 meters.

Whoosh. A blue concentric wave stretched outward and caught one person in its radius. A System window sprang up over the coachman’s round head.

> **System**
>
> - You identified the target with Qi Sense.
>
> **Lv. 4 Jang Sam**

Aha. So that was how it worked.

*Easy, simple, and most of all…*

It was an essential skill for survival. Whether an enemy was strong, weak, or roughly on my level—I could find out at once by using Qi Sense.

*I got a pretty good one.*

I nodded and opened the Quest Window. The moment I checked the new Main Quest, my mouth fell open before I knew it.

“…Huh?”

The world before me seemed to flare into light. If Qi Sense was a single ray reflected in a sewer, this was the sun. My heart pounded, and heat rushed to my head.

> **System**
>
> Quest
>
> **Logout**
>
> Now you must make your way through this harsh Murim.
>
> Grow stronger and become famous.
>
> For that day, when it finally comes…
>
> **Grade:** Main Quest
>
> **Restriction:** Jin Taekyung
>
> **Objective:** Reach the First Rate realm (Incomplete)
>
> Reach Lv. 30 (Incomplete)
>
> Reach 500 Fame (Incomplete)
>
> **Reward:** Logout

The one word I had been desperate to see.

*Logout!*

I was happy, but dazed too. I had been determined to survive by any means necessary, yet a sliver of anxiety had always remained in the back of my mind. *Can I get out? What if I can never leave?* Those ominous suspicions had been there all along.

*I can get out.*

But now things were different. I was certain I could log out. It felt as if my mind had awakened anew.

*Yeah, fuck it. At the end of the day, it’s just a game.*

A quest? How hard could it be?

For seven years, I had crossed the line between life and death almost every day. A Hunter’s ability to survive—and sheer willpower—were beyond comparison with an ordinary person’s.

*And then there’s this power.*

My fist clenched on its own. All of this might be virtual, but the power surging through my body felt real enough.

That was how I knew.

I was stronger in the game than I was in reality.

The difference was tiny, but it was definite.

*It’s all thanks to the System.*

Leveling up, Quests, distributing stats, and skills. All of it was the power of the System—things that were possible because this was a game and I was a player.

With my experience as a Hunter and the System at my disposal, logging out was only a matter of time.

*Once I get out, they’re all fucking dead.*

I’d start by beating the shit out of the game’s developers. Fucking bastards. I was grinding my teeth when someone shouted in my ear.

“Stop!”

* * *

Uniforms. Disciplined postures. Clipped voices.

The moment I saw the martial artists guarding the main gate of the Jin Family of Taiyuan, the word *martial artist* flashed through my mind.

*So this is what a prestigious family is like.*

They were definitely different. The Heavenly Axe and the bandits I’d run into before had been a rabble. These people were more like a trained regular army.

One of the NPCs approached the coachman. He was a martial artist with a young face and thick caterpillar eyebrows.

“I’m Hyuk Mujin, Captain of the Gatekeepers of the great Jin Family of Taiyuan. State your identity and the purpose of your visit.”

Captain of the Gatekeepers. Come to think of it, he was the only one wearing a band resembling an armband. He looked young enough to be twenty, at most.

*Then again, if you’re talented enough, that’s all that matters.*

While I was thinking that, the coachman answered.

“We’re from Honghwaru.”

“Honghwaru? You mean the pleasure house?”

“Yes.”

Through the window, I saw the NPC’s face—or rather, Hyuk Mujin’s face—twist into a frown. His previously polite manner turned curt on the spot.

“What business could a pleasure house possibly have with our family?”

“Ah, well…”

No matter where you went, there were always people like this. The kind who worked for a conglomerate and thought that made them a chaebol. The actual chaebols were somewhere else entirely.

I quietly opened the window and coughed.

“Ahem. Hmm-hmm.”

It was a deliberately conspicuous cough. The famous *Don’t you know who I am?* cough, available only to people who had made it big in life.

“Hmm.”

Sure enough, Hyuk Mujin recognized me at a glance. I opened my mouth with a mild smile.

It was a magic phrase used by high-ranking politicians, soldiers, and businessmen.

“Hmm. Right. Good work.”

I was about to close the window when…

Clack. Rattle.

“Huh?”

It wouldn’t close. A hand had shot forward and caught the window.

The owner of that hand was, of course, Hyuk Mujin. Through the half-closed window, I saw his face, stiff as a board.

“Get down.”

“Me?”

“Who else? Did you think I was talking to the air?”

What the hell? Why was this guy reacting like that?

*He didn’t recognize me after all.*

I put on a generous smile.

“You might not know this, but I live in this house.”

“So do I.”

“No, what I mean is…”

“The Third Young Master of the Jin Family of Taiyuan. Is that what you’re trying to say?”

“…”

He had hit the nail on the head. Hyuk Mujin continued.

“I know perfectly well who you are, Young Master. Now get down from the carriage. We’ll follow procedure.”

What else could I do? He said it was protocol. But warning lights were flashing in my head as I climbed down from the carriage.

*Why does this feel so ominous?*

The other NPCs in the Jin Family of Taiyuan were giving me strangely chilly looks too. Just as their stares began to make my face burn, Hyuk Mujin took out paper and a brush and spoke.

“Name.”

“…”

“I’ll ask again. Name.”

What was this, a criminal interrogation?

I was in a foul mood, but decided to wait and see what happened.

“…Jin Taekyung.”

“Affiliation.”

“Jin Family of Taiyuan.”

“Age and martial arts realm.”

“Twenty. Second Rate.”

Hyuk Mujin’s brush paused.

“Don’t let pointless pride get in the way. Answer honestly.”

Honestly?

*I raised my rank to second-rate by assigning stats. Would that mean anything to you?*

When I simply stared at Hyuk Mujin’s face instead of answering, he shook his head.

“Well, if that’s how you want it, we’ll move on. Now, let’s see… You’ve been away for several days. Where have you been?”

“Honghwaru.”

“Wow, you spent several days at expensive Honghwaru? Must have been nice. You must have blown a fortune. Or did you skim the family funds again?”

“Again?”

“Why pretend otherwise? Isn’t that something the Young Master has done now and then, time and time again, as a matter of course?”

The hostility in Hyuk Mujin’s eyes reminded me of one fact.

*Jin Taekyung.*

I had forgotten for a moment what the character Jin Taekyung was in this game—especially in the Jin Family of Taiyuan.

*The Shame of the Family.*

There was no way the Jin Family of Taiyuan’s NPCs would like someone saddled with a title like that. As if to prove it, their contempt was aimed entirely at me now.

In this game where nothing went the way I wanted.

*Ah, for fuck’s sake…*

Something surged up from deep in my chest. My head throbbed, and heat rose behind my eyes. Then I heard a low voice.

“Third Young Master, I may only be a low-ranking squad leader, but let me say one thing.”

He said it with a look that made it clear what he thought of me: *What a pathetic bastard.*

“Stop disgracing the family’s reputation. At least try to live like a human being. Understood?”

He tossed out that one remark and turned away. I stared blankly at the back of his head, then let out a hollow laugh.

“Live like a human being?”

I knew Hyuk Mujin was nothing more than an NPC who knew nothing.

I knew he was saying it to Jin Taekyung, not to me.

But…

*This is fucking bullshit.*

The fact that this was a game and Hyuk Mujin was an NPC didn’t matter. No—I decided not to think about it.

All the stress that had piled up over the past few days burst out, and even the last of my patience crumbled.

“Hey. You. Stop right there.”

Hyuk Mujin turned around with an annoyed look on his face. I’d wanted to punch that face since earlier.

I beamed like a child who had just seen Santa Claus.

“You’re… fucking dead.”

I sent my clenched fist flying toward his jaw.

* * *

The air was heavy. A pile of documents rose high above the desk. And, as always, a cold-looking escort stood beside his master like a shadow.

Scratch. Scratch.

The Chief of the Gatekeeping Pavilion swallowed. From the moment he entered the office, his mouth had been bone-dry.

“Tell me.”

The calm voice drifting from beyond the pile of documents was an oasis.

The Chief of the Gatekeeping Pavilion finally managed to speak.

“There’s one promising man among my subordinates. He’s quite loyal to the main family, and he has considerable martial talent, but…”

“I’m listening.”

“Perhaps because he’s young, he’s arrogant and insolent. He doesn’t know how to think things through.”

“Get to the point.”

“I hear he got into a fight with the Third Young Master.”

“…I can imagine. What about the youngest?”

“We moved the youngest to Medicine King Hall immediately. He’s unconscious now, with some bruising…”

Silence fell.

“It was all my fault. Please punish me severely!”

The Chief of the Gatekeeping Pavilion bowed deeply, his vision going dark. A long while passed before the voice came again.

“That’s enough. You may leave.”

The Chief of the Gatekeeping Pavilion raised his head, feeling as if he had narrowly escaped death.

“Ah, one more thing.”

“Yes, Lesser Family Head.”

“Could I see that fellow? I’d like to speak with him for a moment.”

“Lesser Family Head, I’m sorry to say this, but his treatment isn’t finished yet.”

“Treatment?”

“Yes. He’s at Medicine King Hall too. I hear one of his bones was cracked.”

“…I see. Then never mind.”

The silence that continued after the Chief of the Gatekeeping Pavilion withdrew was broken when the precariously stacked tower of documents came crashing down.

“Wipeng.”

The thirty-five-year-old Lesser Family Head of the Jin Family of Taiyuan, Jin Wikyung, called to his trusted retainer, his expression stiff.

“Yes.”

“I’m going to step out for a while.”

*Here we go again.*

Wipeng, Jin Wikyung’s escort, let out an inscrutable sigh as he watched his master walk away.
