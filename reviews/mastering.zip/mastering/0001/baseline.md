# Chapter 1

“It’s garbage.”

Jinho delivered the verdict with the solemnity of a judge. He was the manager of the goshiwon[^1] where I lived, a thirty-year-old exam candidate.

We were fairly close, only three years apart, and I remembered how he was always going on about how much he knew about IT. That was why I showed him the capsule I’d picked up, but…

“Is it really that bad?”

“No. I said it’s garbage.”

Wow. Not even a hint of hesitation. For some reason, I felt personally insulted.

“You didn’t even look at it properly.”

Just as I’d said, he hadn’t even looked inside. He’d merely given it a quick once-over, top to bottom, before declaring it garbage. Since I’d been thinking about how much I could get for it secondhand, the blow hit me hard.

“Taekyung. Taekyung. Jin Taekyung. You’re laboring under a serious misunderstanding.”

“…?”

“Shit is shit. You don’t have to dig through it to check for yesterday’s bean sprouts. You can tell it’s shit just by looking at it.”

“Oh.”

“Shh. Don’t say anything more. I wasn’t fishing for praise.”

“Jinho…”

I wanted to kill him. My fist trembled with the urge, and Jinho flinched. Unlike him, who had spent his entire life hunched over a desk, I had a fairly intimidating build.

“Taekyung. Let’s recall Article 1, Clause 12 of the Awakened Persons Special Act. What you’re about to do falls under assault of a civilian by an Awakened…”

“I thought you said an F-rank Hunter like me didn’t even count as an Awakened?”

“I did? When? Was I blackout drunk?”

Watching him make such a fuss, I could only sigh.

My fist slowly dropped.

“That’s right. Good thinking. This field is small enough as it is. If word got around that you assaulted a civilian, you’d get fired from your Guild too…”

“I already got fired.”

“Huh?”

“The moment I showed up, my Team Leader thanked me for all my hard work.”

I’d started that job at twenty. I’d needed to support my family in place of my late father, which was why I’d chosen to become a Hunter.

F-rank. The lowest possible grade, with no particular talent to speak of, but I prided myself on having worked hard. With what I earned, I paid for my mother’s medical treatment and supported my only younger sibling.

But now… it felt as though the past seven years had vanished all at once. I remembered the Team Leader’s impassive face as he informed me of my dismissal a few hours earlier, and my chest tightened.

“Uh… well.”

I gave a short laugh at Jinho’s flustered expression.

“You feel bad, don’t you?”

“Honestly… kind of.”

This guy. A serious expression really didn’t suit him.

“Then buy me a drink. This is when you’re supposed to act like my big brother.”

“Listen to the disrespect on you. Try treating me like your big brother before you say something like that.”

He said that, but still jerked his chin for me to follow. From his expression, we were going to drink until one of us fell over tonight.

* * *

A Gate marks the boundary of the world. Outside it—in other words, in the modern world—is the civilized society we know. Go inside, though, and it’s crawling with monsters no one has ever seen or heard of.

The weakest and most common of them were goblins—even an F-rank Hunter like me could handle one.

The reason I’m bringing this up now is…

“Gwaah. Gwaah.”

*How can a person even do that?*

Was that thing human or a monster? Leaning against a utility pole and vomiting, Jinho looked just like a goblin that had taken a hard blow to the solar plexus.

“Hey, Jinho. Mr. Seong Jinho. Try to come to your senses.”

“Gwaah?”

…Just carry on.

*I told you to drink slowly.*

He had been pounding drinks like a lunatic from the very first round, and this was how he’d ended up. Never mind that I’d had to pay the bill—I was soaked through after carrying the dead-drunk man all the way back to the goshiwon.

Sweat was a given. Vomit was extra. It was obvious whose it was.

While he retched intermittently in the background, I watched the sun sink toward the horizon.

*Getting fired wasn’t bad enough. Fuck.*

The memories of the day flashed through my mind like a panorama.

*What a day this is turning out to be.*

“Urp. Urrrgh. Where are we, driver? Huh?”

You were the highlight of it all.

“We’re home. We’re here, so try to wake up.”

“Home? My home’s in Gangwon Province. Oh, Mom. Mom! I want some of my mom’s doenjang stew[^2].”

“Oh, for crying out loud. It’s the goshiwon, Jinho.”

“The goshiwon? Hope Goshiwon?”

“Yeah. So try to wake up.”

“Hope… Right. Hope can’t be bought with money. My mom always said it was in everyone’s heart. She makes incredible doenjang stew.”

I waited patiently until he reached the part about doenjang stew, then punched him in the gut.

Even while vomiting, he mumbled Article 1, Clause 12 of the Awakened Persons Special Act, proving that he was, in fact, an exam candidate.

* * *

“I feel gross.”

I went straight to the shower room in the goshiwon and showered for thirty minutes, but I still felt as if the smell of vomit were clinging to the tip of my nose.

When I returned, sniffing all the way, two nuisances were waiting in my room.

“Gwaah…”

One was Jinho, dead drunk, and the other was…

“Oh, I forgot about this.”

The capsule. I’d left the refrigerator-sized thing in my room, barely ten square meters, and it felt as if it had filled the entire space. I retreated onto the bed and began wondering what to do with it.

*Should I take it back where I found it?*

I could hand it over to a scrap dealer instead. What were scrap-metal prices like these days? It weighed at least fifty kilograms, so I could probably get enough for a few snacks.

*I thought it was a fairly useful piece of equipment.*

Shit, huh? Was it really that much of a piece of junk?

Come to think of it, I hadn’t even looked inside. Curiosity got the better of me, and I examined the capsule.

“First, the exterior is… not great.”

The capsule’s surface was yellowed with nicotine or something, and rust seemed to have formed in places. Once I let go of my attachment and took a proper look, I understood what Jinho had meant.

“Is this how you open it?”

I pressed the lone button sticking out, and the lid opened to reveal the interior. I had expected something impressive, but there was nothing much to see after all.

There was only an ergonomically designed chair for extended play and a VR helmet that enclosed the entire head… Huh?

“What’s this? An instruction manual?”

More precisely, it was a small booklet labeled *Product User Manual*.

Did people really leave instruction manuals inside things they were throwing away? Especially in a piece of junk like this?

Curious, I opened to the first page.

> **Product User Manual**
>
> **Product name:** Virtual Reality Interface  
> **Model:** ARK-2020  
> **Manufacturer:** H Soft  
> **Manufacturing date:** January 1, 2020

I skimmed the print without much thought until the manufacturing date stopped me.

January 1, 2020. It had to be a printing error. Surely.

*What kind of lunatic would have made a game machine on that day—no, during that period?*

That period was the Great Cataclysm.

January 1, 2015. Humanity received more than a New Year’s sunrise.

Gates—or dungeons, as they were also called—began appearing all over the world, and monsters no one had ever seen or heard of poured through them.

Monsters and Awakened. War and destruction…

The unreal invaded reality, and the greatest war in Earth’s history ended only with the death of the monsters’ lord, the Demon King Asmodeus.

That day was January 1, 2020. It was known as Victory Day.

*So that’s impossible.*

I clicked my tongue and turned the page.

> **Warning**
>
> - The player cannot log out at will.
> - If the player dies during gameplay, resurrection is impossible.

“Oh. I see.”

I nodded and lay down on the narrow mattress. There were still a few pages left, but who cared?

“I should get some sleep.”

Rather than read an instruction manual written by a lunatic, I might as well sleep. I pushed Jinho into a corner and closed my eyes.

“Gwaah. Gwaah.”

“…”

“Gwaah. Gwaah.”

“…”

Did that capsule have a soundproofing function?

* * *

The chair was hard. It had been made in 2020, so it was the same age as me. A twenty-seven-year-old chair. Its cushion had gone flat long ago.

I took comfort in the fact that it didn’t smell and pulled the blanket up to my neck.

“Gwaah. Gwaah.”

…I even put on the VR helmet.

*Wearing something like this is going to make my neck hurt.*

That minor complaint vanished the moment I put on the helmet. A world of complete silence. A stillness without so much as a whisper of noise.

But instead of sleep, my thoughts began to stir.

*What am I going to do tomorrow?*

Hunters were certainly a highly paid profession, but that depended on your rank.

F-rank Hunters like me were a dime a dozen, and unless you belonged to a Guild, you had to show up at a day-labor agency before dawn.

Being unaffiliated was miserable. Government policy was never kind to unaffiliated Hunters, and the punishing tax rates imposed on Hunters were enough to take your breath away just hearing about them.

*So now I’m one of them.*

Unlike me, my mother and younger sister lived in an apartment in a Safety Sector. It was an extravagant expense for an F-rank Hunter, but nothing mattered more to me than my family’s safety.

Until now, I had barely managed to come up with enough money to renew their jeonse lease each year.[^3] But from now on… who knew?

*Fuck. I don’t know.*

I suddenly thought of my late father.

He had devoted himself to his family and was respected by society, but he died when I was seven.

A monster attack caused by a Gate breach. As an ordinary office worker, he probably never had a chance.

If my father were still by my side, could he have shown his son which way to go?

*I’ve still done my best all this time. Please believe in me.*

Maybe it was the alcohol finally catching up with me. Maybe it was thinking about the past. Without realizing it, I went slack and my eyes began to close.

As I surrendered to the wave of sleep pouring over me, I thought:

*I hope things will be a little better when I open my eyes.*

Someone’s voice pierced my ears, but I didn’t care anymore. I slipped gently into sleep.

> **System**
>
> Player detected. …Unregistered player. Register as a new player?
>
> No response for an extended period. Proceeding automatically.
>
> 1%… 27%… 94%… Complete.
>
> Player Jin Taekyung registered to the device.
>
> Proceeding to selection. Would you like to log in to Murim?
>
> No response for an extended period. Proceeding automatically.
> …May fortune favor you in battle!

[^1]: A goshiwon is a very small, inexpensive room-for-rent housing arrangement, often with shared facilities.
[^2]: Doenjang is a fermented Korean soybean paste commonly used as the base of a savory stew.
[^3]: A Korean jeonse lease is secured by a large refundable deposit in place of monthly rent.
