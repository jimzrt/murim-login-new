# Chapter 4

Jang Sam was a bandit.

A local born and raised near Mount Wutai, he had never once left the area. Since around the age of twenty, he had made a living extorting tolls from travelers who looked easy to bully.

Perhaps thanks to his diligent round-the-clock operation, Jang Sam the Heavenly Axe had eventually become fairly well known.

Today was no different. He had risen before dawn and set out to work with his five loyal underlings, the Five-Colored Ghosts… but for some reason, his feet refused to stop.

How long had he walked, leaving his home turf of Mount Wutai far behind? At last, when his feet finally stopped, he saw a carriage approaching in the distance.

*How did I get all the way here?*

Had a ghost possessed him? Jang Sam was bewildered, but the moment he saw the luxurious four-horse carriage, his professional instincts came roaring back to life.

*I have to take that.*

When Jang Sam and the Five-Colored Ghosts blocked the road, the coachman pulled on the reins.

Four fine steeds, their coats gleaming, snorted clouds of vapor as they came to a halt. At a glance, each one looked worth a thousand nyang at least.

*Today’s my lucky day.*

Jang Sam smiled contentedly and adjusted his grip on his axe. Now, tighten the muscles in the dantian. One, two—

“Hand over your money!”

* * *

*What was that voice? Is he an opera singer?*

But it would take more than that to make me blink. I’d spent seven years as a Hunter and been through every kind of hell imaginable—even aerial combat.

…Still, he was kind of scary.

“There are six of them in total. I don’t see any signs of an ambush.”

The coachman reported the situation in a voice as calm as a secret agent’s.

*Does this guy have some kind of hidden ace? Why is he so relaxed?*

When I stared at him, he scratched his head.

“It happens from time to time. Though this is a first in this area.”

“Why?”

“Why? Unless it’s a sizable mountain stronghold, attacking a martial family is practically suicide. I wonder what kind of reckless fools would try robbing people in the Jin Family of Taiyuan’s own backyard.”

*Who else? Tutorial NPCs.*

Judging by the way he kept calling it the Jin Family’s backyard, we must have been fairly close.

*Should I stall for time?*

My current realm was second-rate.

The way my body felt after distributing my stats was beyond what I’d experienced as an F-rank Hunter, but I had no idea whether it was enough to hold its own in Murim.

Six against one. Six against two, if I counted the coachman.

*Could I do it?*

There was a reason people said numbers could overcome skill. The moment my hands and feet were tied, I’d be finished.

“How much farther to our destination?”

“We’re nearly there. Another hour should be enough.”

*Another hour…?*

I’d suspected it, but apparently, the coachman and I had very different definitions of *nearby*.

*What do you mean, nearly there?*

Maybe it was because this was a continent-sized setting. The scale was different. The scale.

Either way, I had to assume no reinforcements were coming. At least I wasn’t alone.

The coachman’s unflappable attitude practically screamed that he was a master.

“Shall I handle this?”

As he said it, he coiled the whip in his hand with enough force to suggest that one crack would separate the bandits’ bones from their flesh.

*He’s a master!*

Of course. I was a scion of a prestigious martial family and a VIP customer of Honghwaru. There was no way they would have sent an ordinary coachman with me.

*Wolhwa must have arranged this. She isn’t just beautiful—she’s kind, too.*

My anxiety vanished, replaced by a pleased smile. The coachman must have taken it as my permission, because the moment he turned away, a second shout rang out.

“You bastards! Can’t you hear what the Heavenly Axe is saying?”

I leaned out past the carriage window and saw a hairy man shouting while holding an enormous double-bladed axe. His upper body was massive, and his arms and legs were as thick as pillars.

But the coachman muttered as if the sight were laughable.

“Where do these little pups get off blocking our way?”

*Damn, that aura.*

Then the coachman laid into them.

“How dare bandits who suck the blood from innocent civilians block the road before us! I will have you dragged to the authorities and subjected to the full severity of the law!”

It was a speech worthy of Judge Bao, but the hairy man—the Heavenly Axe—and his underlings didn’t seem particularly moved.

“Yeah, we blocked the road. What are you going to do about it?”

“I will gouge out your eyes, grind your limbs to powder in a mortar, and scatter them across the Nine Provinces! I will also exterminate all nine degrees of your kin—”

*…Those punishments are getting a little extreme. That’s practically treason.*

As if he had read my thoughts, the Heavenly Axe spoke up.

“Hey, is there an imperial prince riding inside? Listening to you is making my knees shake. Why don’t you show us that precious face of yours?”

“You will regret not retreating now once you learn this man’s identity!”

“Okay, okay. We get it. Now come out already.”

“You fools…!”

The coachman clicked his tongue and turned toward me. My heart began to race. Was I finally about to see a true Murim master in action?

“Young Master, I believe you’ll have to come out.”

“Huh?”

*Me? Why me?*

“They won’t shed tears until they see the coffin. Blocking your path so brazenly—they’ll pay dearly for failing to recognize a master.”

With a determined look, he opened the carriage door for me.

“I have heard much of the Heaven Shaking Sword’s fame. A genius swordsman who reached the Peak realm at barely twenty! You cannot imagine how my old heart trembled whenever I heard stories about you, Young Master.”

*…The Heaven Shaking Sword? A genius swordsman?*

My thoughts tangled together. Who was the Heaven Shaking Sword? Who was this genius swordsman who had reached the Peak realm? And what the hell was this coachman playing at?

*You said you’d handle it. Aren’t you a master?*

“You bastards! Do you know who this man is?”

This was bad. The coachman was careening out of control like an eight-ton truck with a broken steering wheel.

*No. Stop. Please stop!*

I grabbed his wrist tightly, and he turned to look at me.

He smiled as if he knew everything. His eyes shone with boundless trust.

“W-wait. I’m Jin—”

Before I could say another word, his thunderous voice rang out.

“He is the Second Young Master of the Jin Family of Taiyuan, the Peak master whose name resounds throughout Shanxi! The Heaven Shaking Sword, Young Master Jin Mukyung!”

“I’m Jin…Taekyung.”

At that moment, a cold wind blew.

“Pardon?”

“I mean, I’m Jin Taekyung, not Jin Mukyung. And I’m the Third Young Master, not the Second…”

“…The Third Young Master? That Third Young Master?”

*Yes, you idiot.*

The coachman’s pupils began to tremble. It was an earthquake measuring 8.0 on the Richter scale.

“Th-then where is Young Master Jin Mukyung?”

“How should I know?”

*He’s probably sleeping right now.*

The coachman stared at me with the expression of a man who had lost his country, then collapsed like an inflatable toy with the air let out of it.

He had fainted.

*Fuck. Some master.*

I released his wrist.

His wrist was as thin as a chicken bone. Something had felt off from the moment I grabbed it. He had put on quite a show, only to turn out to be an ordinary civilian.

“Ha-ha! Ha-ha-ha!”

The bandits shrieked with laughter. My back was already damp with cold sweat, and I hadn’t even noticed when it started.

*If things go really badly…*

I couldn’t bring myself to say the word *death*. I swallowed it instead.

I swept my tense gaze over the bandits.

*Fuck. I’d rather fight six goblins than deal with this. How am I supposed to beat bodies that huge…?*

Wait.

“Huh?”

Was it my imagination? No matter how I looked at them, it wasn’t.

Massive upper bodies. Thick arms and legs. And…short.

The other five weren’t much different. The Heavenly Axe at least had a decent physique, but these guys were five hundred light-years away from anything you could call “well-built.”

In other words, the bandits’ physiques looked a lot like—

“They’re goblins?”

*Goblins?*

I stood there dazed for a moment, but a flying axe snapped me back to reality. They had the numbers and they were launching a preemptive attack, too?

“Hey, hey! Wait a second!”

The axe slammed into the ground ten meters ahead of me. No—it toppled over. The bandit who had thrown it scratched the back of his head sheepishly.

“Should I have thrown it a little higher?”

*…Maybe.*

*Could I actually survive this?*

The monster I had fought more than any other over the past seven years was the goblin.

Naturally, I knew everything there was to know about them. It was even why I had chosen a spear as my primary weapon when I was a novice Hunter. A spear gave me an enormous advantage in attack range.

And these bandits were exactly that size. To me, they didn’t look like bandits at all. They looked like six goblins. The Heavenly Axe was the goblin chieftain.

*The other five might be even weaker than goblins.*

At least goblins could shoot poison darts. Judging by the way this one had thrown that axe, I had a hunch. A very strong hunch.

I licked my dry lips, then raised both hands high.

A few of them looked confused at my gesture of surrender, while the Heavenly Axe smiled proudly, like a father looking at a son freshly discharged from the military.

“Good lad.”

*Yeah. Enjoy your laugh while it lasts.*

One step, two. I slowly closed the thirty-meter distance between us.

With a steady stride and balanced posture. One breath per step. My breath escaped my mouth in white clouds that pierced the dawn air.

I could feel it from the simple act of putting one foot in front of the other.

*It’s different!*

I realized it once more.

The version of me inside this game was stronger than the real me.

My heart pounded. At the same time, a warning stirred in the back of my mind.

I had to stay focused until the very last moment.

“I heard the Jin Family had a son they’d given up on. third-rate at martial arts, first-rate with women. Looks like you’ve got decent instincts, too.”

The Heavenly Axe spoke with the hand holding his axe hanging loose at his side.

I knew exactly how I looked to them.

A useless playboy with a good family name. Empty hands.

The Heavenly Axe had let his guard down.

*And letting your guard down gets you killed.*

I might send most of my salary to my family and live miserably in a tiny goshiwon room, but I was still a Hunter.

Even an F-rank Hunter risked his life fighting inside Gates. No—an F-rank Hunter had to risk his life precisely because he was only F-rank.

I was a fighter who had battled every day for seven years without missing one, a martial artist in all but name.

So I knew.

Life and death were separated by a hair’s breadth. Letting your guard down was the same as dying.

The distance had been cut in half. My steps gradually quickened.

The Heavenly Axe beckoned me over.

“Now, now. Take your time. Don’t lower your price by tripping on the way.”

Twenty meters.

“Boss, doesn’t the way he’s toddling over look just like a puppy?”

Fifteen meters.

“A puppy? Ha-ha-ha! You’ve got that exactly right!”

Ten meters.

The moment I took my next step, something hot began to churn in my stomach.

It was a sensation I had never experienced before, yet somehow, it felt strangely familiar. What was it?

*Could it be…internal energy?*

The heat flowing from my dantian raced toward my lower body.

It had only one purpose: to make me faster, lighter, stronger!

Whoosh. I drew in a long breath. Every muscle in my body drew taut like a bowstring. Then came the final step.

Boom!

I shot straight forward. The ground sank beneath my foot, and the sound followed after me. In frozen time, the Heavenly Axe’s mouth slowly fell open.

“No way…”

The Heavenly Axe and his underlings stared at me in disbelief.

I could see everything about them now. Feel it.

Their stiff, greasy hair. Their cracked lips, like a rice paddy in a drought. Their teeth that reeked just from looking at them…

I could see all of it.

The corners of my mouth lifted before I knew it.

*Open Inventory. Equip [Sharp Spear].*

A cold spear shaft appeared in the hand I had thrust into empty air.

I drove it forward with all my strength. The Heavenly Axe hastily raised his axe to block, but the sharp spearhead shattered the axe blade and punched straight through his chest.

At the same time—

> **System**
>
> Critical One Strike! Status effect Bleeding activated!

“Ghk!”

A fountain of blood erupted. The Heavenly Axe’s eyes flickered once, then went dark.

> **System**
>
> Lv. 10 Jang Sam defeated.
>
> Level up!
>
> You received 10 Stat Points as a level-up reward.
>
> You received 10 Skill Points as a level-up reward.
>
> Jin Family’s Cultivation Technique unlocked.

*Whew.*

I let out a long breath. A notification had sounded, but all I could hear was my own pounding heart.

One breath. Everything had happened in a single breath. I pulled the spear from the Heavenly Axe’s lifeless chest.

*So this is possible.*

Raise my abilities with points, reinforce them with internal energy, and chain them together with skills. This was the power of the System—the one power that belonged to me alone.

A power F-rank Hunter Jin Taekyung could never have dreamed of.

*I can do this. I will.*

The road home suddenly looked brighter and wider.

I gripped the spear shaft and turned around.

“So…”

The five pairs of eyes fixed on me wavered uncertainly.

“Who else wants to try me?”

*Start with the bastard who threw that axe.*

“…”

Thud. Thud. Clatter.

The five bandits exchanged glances, then dropped their weapons and prostrated themselves.

“Please forgive us, Great Hero!”

> **System**
>
> The enemies have lost their will to fight and surrendered after losing their leader.
>
> Defeat the Bandits complete.
>
> You have fully recovered from all fatigue and injuries.
>
> You have subdued the bandits. Fame increased by 10.
>
> Tutorial—Stage 3 complete. Rewards will be distributed.
>
> Chain Quest Tutorial—Stage 4 created.

*Now I can finally catch my breath.*
