# Chapter 2

A cold wind brushed my face.

I’d been sensitive to the cold since I was a kid, so I kept my windows closed all year round. Who had opened the window, then?

*Obviously.*

Seong Jinho, that miserable excuse for a human being.

Grumbling, I pulled the blanket up to my neck. The woman lying beside me let out a soft whine.

“…Huh?”

*A woman? What woman?*

I woke in an instant and shot upright like a private hearing reveille. Then I slowly turned my head.

“Tài lěng le.”

Good heavens. I was stunned twice over. First, because I couldn’t make sense of the situation. Second, because the woman lying beside me was unbelievably beautiful.

She kept muttering words I couldn’t understand as she burrowed deeper beneath the blanket. Even in my dazed state, she was beautiful enough to set my heart pounding.

If that cold wind hadn’t blown in right then, I might have stared at her for quite a while.

*But where am I?*

I looked around. Red candlelight glowed softly through the room. A strangely provocative fragrance filled the air, and a beautiful woman lay beside me, covering her naked body with a blanket.

A place I’d never visited but had heard plenty about.

*A room salon?[^1]*

But why was I here?

I was completely bewildered. What had happened? Yesterday, I’d had a drink with Jinho and returned to my room at the goshiwon.

I clearly remembered climbing into the capsule to escape Jinho’s thunderous snoring.

*Am I dreaming?*

I pinched my forearm hard. It hurt. This wasn’t a dream.

The situation was becoming more and more baffling. After staring blankly around the room, I grabbed the woman by the shoulder and shook her.

“Excuse me?”

The woman peered at me through half-lidded eyes. Her irises shimmered dark blue, and my heart began pounding again.

“Who are you?”

“Shenme?”

“Ah, Ms. Sunmi. But that wasn’t what I meant…”

“Shenme?”

“…Yes?”

“Shenme…?”

*What the hell is this?*

For a moment, we stared at each other in silence. Then I realized it. This woman wasn’t Korean.

“Are you Chinese? Or Filipino?”

“…Zhōngguó rén ma?”

*This is useless. We can’t communicate at all.*

I scratched vigorously at the back of my head in frustration. The next moment, I sprang up like a released spring.

Ding.

> **System**
>
> Would you like to check your unread messages?
>
> Accept / Decline

A bell rang from somewhere.

A square window floated in midair like a ghost.

I had no idea where it had come from—or, more importantly, why I could see something like this. Goose bumps prickled across my skin.

“What the fuck is this?”

I lashed out on reflex, forcing the words through clenched teeth.

My fist pierced the square window—or rather, passed through it. More precisely, it passed through the word *Accept*.

Ding.

> **System**
>
> No response for an extended period. Randomly selecting a character.
>
> Searching Murim… Starting play as character Jin Taekyung!
>
> Logged in to Murim.
>
> First-login rewards will be granted.
>
> The player’s current language can be changed. Apply the Universal Language Pack?

*A character? Murim? Login?*

“Huh? Huh?”

> **System**
>
> Applying the Universal Language Pack.

“Wait, hold on!”

That was when the woman spoke.

“Young Master Jin. Are you feeling ill?”

She was speaking perfect Korean. I looked back and forth between the square window announcing that the Universal Language Pack had been applied and the woman, then thought:

*What the hell is going on?*

* * *

Wolhwa. That was the woman’s name.

She had smooth, pale skin and a face the size of my fist. Her delicate features were perfectly arranged, and her eyes were so large and clear that she could have put a celebrity to shame.

I marveled at her all over again.

*The graphics are incredible.*

By then, I’d already worked out the general situation. Once I put a few things together, the truth was simple.

Murim. Character. Login. Play. The last place I’d fallen asleep was inside a game capsule. And most importantly—

> **System**
>
> Would you like to open the message window?
>
> Accept / Decline

There was a System window. I could issue commands aloud or in my head. Scratching my head acted as a kind of shortcut. I could even click the options I wanted in midair.

*The more I see, the more amazing this gets.*

It was a far cry from the last game I’d played, but this was a game. I was playing a game right now.

*But when did I log in?*

I didn’t remember plugging anything in. Just as I tried to recall what had happened the night before, Wolhwa suddenly held out a bowl of water in both hands.

“Drink. You don’t seem fully awake yet.”

*The AI is incredible, too.*

I stole glances at Wolhwa’s face as I drank the water, then nearly jumped out of my skin.

*What the hell?*

The cold water slid down my throat, cooling me all the way to my stomach. The sensation was so vivid that goose bumps rose on my forearms.

The lifelike graphics and the NPC’s artificial intelligence were one thing, but even a sip of cold water felt too real for this to be a game.

Wow. I’d heard that technology had advanced by leaps and bounds, but I’d never imagined it had come this far. Now I understood why people became gaming addicts.

*So this is why everyone goes on about virtual reality.*

I looked around with my mouth hanging open like a kindergartener at an amusement park. Then acrid smoke rose from somewhere and obscured my view.

I turned my head. Wolhwa was watching me intently, a long-stemmed tobacco pipe already between her lips.

“Why…?”

She seemed so much like a real person that I slipped into polite speech without thinking. Of course, the fact that she was stunningly beautiful had something to do with it.

Wolhwa exhaled a stream of smoke and answered.

“Just because. I wanted to look at you?”

*I thought she was just a pretty face, but she had one hell of a presence, too.*

If a bunch of high school girls saw her, they’d be screaming “Big Sis!” while blood poured from both nostrils. From head to toe, she practically had one phrase written all over her.

*Femme fatale.*

*They really nailed her character concept. Plenty of players probably start the game just for Wolhwa.*

“Young Master Jin, do you know you’ve been acting strange today?”

*Young Master Jin? What an embarrassing way to be addressed.*

Still, I pretended not to notice. Somehow, I wanted to enjoy the situation a little.

*It’s a game, after all.*

“What do you mean?”

“Everything? You keep staring into empty air as if you’ve lost your mind, and now you’re suddenly speaking formally. I can’t make heads or tails of you.”

The instant Wolhwa finished speaking—

Ding.

> **System**
>
> Tutorial Quest created.

*The way this game progresses is pretty innovative.*

Usually, games started with something like, “At last, you’re awake,” before immediately handing out a tutorial quest.

*Is this what they call freedom?*

“Uh… Check quest?”

Even as I said it, I wasn’t sure whether that was the right command. But with the familiar sound effect, a quest window appeared at once.

> **System**
>
> Quest
>
> Tutorial—Stage 1
>
> You are now taking your first step into Murim.
>
> Gather basic information and understand the situation.
>
> **Grade:** Tutorial (Chain Quest)
>
> **Restriction:** First-time players
>
> **Missions:** Gather Information (Incomplete)
>
> Understand the Situation (Incomplete)
>
> **Rewards:** Sturdy Martial Uniform Set
>
> Character Status Window unlocked
>
> Inventory function unlocked
>
> Skill Window function unlocked
>
> Chain Quest

*Gather information? Understand the situation?*

I hadn’t played many games, but I’d never seen a quest like this before.

Usually, they had you kill a few rabbits or practice using the game interface.

Still, I had to give it a try.

“How much do you know about me?”

Even I thought it was a blunt question. I could see Wolhwa smiling through the tobacco smoke.

“That’s an interesting question. Should I say you’re just like the rumors?”

“Rumors?”

“The stories you already know so well, Young Master. They aren’t exactly flattering enough to tell you to your face.”

“That’s fine. Let’s hear them.”

I was growing more interested in this game by the minute. It was the first game I’d played in a long time, but more than that, its approach was refreshingly different from the usual. Whoever had made it knew how to build a game.

“I’m just curious whether they match the rumors I’ve heard. It’s not like this has only been going on for a day or two. Why would I get offended?”

“…If you insist.”

*Got her.*

I smiled inwardly, pleased. Now all that remained was to pry out some real information.

“First. Do you know who I am?”

It was an even stranger question than the one before, but Wolhwa answered without hesitation. She almost seemed to be enjoying the situation, too.

“The youngest son of the Jin Family of Taiyuan, who came of age at twenty this year. Surely I don’t need to tell you his name as well?”

I answered confidently.

“I know. Jin Taekyung.”

*My name is Jin Taekyung. I’m the youngest son of the Jin Family of Taiyuan.*

At my confident reply, Wolhwa choked in the middle of exhaling smoke.

“Second. What kind of place is the Jin Family of Taiyuan?”

After barely managing to stop coughing, Wolhwa answered.

“They have a good reputation among the public. From time to time, they wipe out bands of mounted bandits, and when droughts come, they distribute relief grain before even the magistrate’s office does.”

*That’s it?*

As if she had noticed my disappointment, Wolhwa continued.

“More than anything, they’re a prestigious family representing Shanxi. You could call them a deeply rooted old tree.”

“Oh!”

I let out an involuntary exclamation—not because I was moved by the greatness of the Jin Family of Taiyuan, but because of the System notification.

Ding.

> **System**
>
> Information about the Jin Family of Taiyuan gathered.
>
> Title Scion of a Prestigious Family acquired. Check it later through the Status Window.

*A title? Scion of a Prestigious Family?*

I guessed it was something like a title in a fantasy game.

*Dragon Slayer, or something like that.*

You received one after accomplishing a certain feat, and equipping it granted additional effects. In that respect, I had to say I was pretty lucky.

*This guy really was born with a silver spoon in his mouth.*

Being born into a prestigious family counted as an achievement. It pissed me off and made me happy at the same time. That meant the random character selected against my will had turned out to be a lottery winner. But the story didn’t end there.

“I’ve heard there are problems inside and outside the family these days.”

“Problems? What kind of problems?”

Come to think of it, the quest window’s information-gathering mission was still marked *Incomplete*. That meant there was more information to collect.

“Externally, there’s the conflict with the Mount Heng Sword Sect, which is constantly eyeing the position of Shanxi’s hegemon. Internally…”

Wolhwa leisurely tapped the ash from her pipe.

“I hear that family’s third son is a notorious good-for-nothing.”

“Ah. There’s always one of those wherever you go.”

I nodded unconsciously, then an uneasy feeling came over me.

“Excuse me.”

“Yes?”

“I’m only asking as a joke, but how many sons does the Jin Family of Taiyuan have?”

She answered with a sunny smile.

“Three.”

The Jin Family of Taiyuan had three sons, and I was the youngest of them. But the third son was a notorious good-for-nothing. Which meant—

*Fuck. That’s me, isn’t it?*

Ding.

> **System**
>
> Title Shame of the Family acquired. Check it later through the Status Window.
>
> Gather Information complete.

I couldn’t decide whether to laugh or cry. Then I saw Wolhwa snickering and let out a hollow laugh myself.

*Well, better to look on the bright side. So what if I’m the shame of the family? It’s only a game, anyway.*

I opened the quest window and confirmed that *Gather Information* had changed to *Complete*.

*The problem is understanding the situation.*

This damn quest was so vague that I had no idea what exactly it wanted. In the end, was Wolhwa my only solution?

“Where are we?”

“Honghwaru, the finest pleasure house in Shanxi. This is my room.”

Through our conversation, I learned a few more miscellaneous facts.

We were in Honghwaru, located in the heart of Taiyuan. Wolhwa was a fairly high-ranking courtesan, and I had spent the night with her… Ahem.

Despite all the things we discussed, no System notification appeared. Eventually, I ran out of questions to ask.

At the very end, I was reduced to asking this:

“What’s my situation right now?”

Wolhwa sighed.

“Young Master Jin, I’m sorry to say this, but you seem a little crazy right now. How about getting some rest?”

*Yeah. I feel like I’m going crazy, too.*

As sunlight streamed through the window, I began to wonder what on earth I was doing.

*This isn’t some kind of mystery game.*

The graphics and artificial intelligence were all great, but getting stuck on the tutorial had completely drained the fun out of it. If there was one thing I’d learned, it was that the capsule I’d found yesterday was a much better piece of equipment than it looked.

A game this advanced had to require serious hardware, yet I hadn’t experienced a single bit of lag. It should sell for a decent price on the used market.

*I need to start looking for a new job today, too.*

Still, the game hadn’t been bad for the little while I’d played it.

I gave Wolhwa a final glance and shouted:

“Log out!”

> **System**
>
> Logout is impossible.

*Huh?*

“Log out.”

> **System**
>
> Logout is impossible.

*What’s going on?*

An error? Or had the ancient capsule finally started lagging?

“…Log out?”

> **System**
>
> Logout is impossible.

There was no doubt about it. Error or lag, the damn old capsule had finally caused trouble. I tried ten more times after that, but every attempt failed.

By this point, my anger had gradually turned into worry and regret.

*Is something bad going to happen to me?*

*I shouldn’t have picked it up just because it was free. I should have thrown it away the moment Jinho called it garbage. Or at least the moment I read that insane instruction manual…*

*No. Wait.*

The instruction manual. That was right—I’d read it. More precisely, I’d read a few of the warnings before tossing it aside, but I had read them.

*What did they say?*

The moment I finally remembered every warning I’d managed to read, a chill ran through my entire body.

> **Warning**
>
> - The player cannot log out at will.
> - If the player dies during gameplay, resurrection is impossible.

*I’m trapped inside the game? Me?*

The System notification answered my question for me.

Ding.

> **System**
>
> Understand the Situation complete.
>
> Tutorial—Stage 1 complete. Rewards will be distributed.
>
> Status Window activated.
>
> Skill Window activated.
>
> Inventory activated.
>
> Chain Quest Tutorial—Stage 2 created.

At that moment, a single thought filled my head.

*I’m fucked.*

[^1]: A room salon is a Korean private-room entertainment venue where customers are served food, alcohol, and conversation by hostesses.
